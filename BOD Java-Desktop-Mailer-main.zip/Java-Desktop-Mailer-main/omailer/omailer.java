package omailer;

import java.io.IOException;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

public class omailer {

	public static void main(String[] args) throws AddressException, MessagingException, IOException {
	new frame();
		
	}


	

}
